
/*
 * File:   main.cpp
 * Author: Eurico Santiago Climaco Rodrigues
 *
 * Created on 7 de maio de 2024, 16:34
 */

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <math.h>

 const int TAM = 100;

using namespace std;

typedef struct {
    string modelo;
    string marca;
    string tipo;
    int ano;
    float km;
    float potencia;
    string combustivel;
    string cambio;
    string direcao;
    string cor;
    int portas;
    string placa;
    float valor;
    bool valido = true;
}Carro;

/*
 * Trabalho de manipulação de registros em vetores e construção de estatísticas 
 * com variáveis simples em estruturas de controle.
 */
int main(int argc, char** argv) {
    // Variaveis 
    string modelo, marca, tipo;
    int ano, portas;
    float km, potencia, preco;
    string combustivel, cambio, direcao, cor, placa;
    
    int op, encontrado, i, totalveiculos, carromin, carromax = 0;
    float hatch = 0, suv = 0, pickup = 0, seda = 0, passeio = 0, van = 0, flex = 0, gasolina = 0, diesel = 0, jurosmes, financiamento, somajuromes;
    float valor, valor2, porcentotipo, minvalue = 1000000000000, maxvalue = 0, seguro, conjunto, med, qntd, media[TAM];
    string busca;
    Carro carro[TAM]; // vetor de registro

    ifstream BD("BD_veiculos.txt"); // abrindo arquivo para leitura
    if (!BD.is_open()){ // verificando se o arquivo esta aberto
        cout << "Falha ao abrir  o arquivo";
        return 1;
    }
    while (i < TAM){// salvando dados do arquivo no vetor de registro
        BD >> carro[i].modelo >> carro[i].marca >> carro[i].tipo >> carro[i].ano >> carro[i].km >> carro[i].potencia >> carro[i].combustivel >> carro[i].cambio >> carro[i].direcao >> carro[i].cor >> carro[i].portas >> carro[i].placa >> carro[i].valor;
        i++;
    }

    BD.close(); // fechando Arquiv

    do {
        // iniciando repetição principal do menu
        system("clear"); // limpando terminal
        for (int i = 0; carro[i].modelo != "fim"; i++){// exibindo veiculos
            if (carro[i].valido == true){
                cout << "Modelo: " << carro[i].modelo << endl << "Marca: " << carro[i].marca << endl << "Tipo: " << carro[i].tipo
                << endl << "Ano: " << carro[i].ano << endl << "Placa: " << carro[i].placa << endl << endl;
            }
        }
        //MENU
        cout << "----------------------------------------------------------------\n\n";
        cout << " Sistema de Banco de Dados de Veiculos\n\n";
        cout << "----------------------------------------------------------------\n\n";

        cout << "1 - busca de um veículo pela placa, com opção de exclusão da base de dados\n";
        cout << "2 - busca de veículos pelo tipo\n";
        cout << "3 - busca de veículos pelo câmbio\n";
        cout << "4 - busca de veículos por um faixa de valores\n";
        cout << "5 - Incluir veiculo no Banco de Dados.\n";
        cout << "6 - relatório do banco de dados.\n";
        cout << "0 - Sair\n\n";
        cout << "----------------------------------------------------------------\n\n";
        cout << "Opção -> ";
        cin >> op;
        switch (op){ // operações
            case 0:
                break;
            case 1: //Busca Veiculo
                encontrado = 0;
                cout << "\n\nDigite a Placa do veiculo: ";
                cin >> placa;
                for (i = 0; carro[i].modelo != "fim"; i++){
                    if (placa == carro[i].placa && carro[i].valido == 1){// verificando se o veiculo existe ou é valido
                        encontrado = 1;
                        break;
                    }
                }if(encontrado == 1){// condicional se o veiculo é existente
                    cout << "\n\nveiculo encontrado:\n\n";
                    cout << "-------------------------------------------------------------------------------------\n";
                    cout << "Modelo: " << carro[i].modelo << endl << "Marca: " << carro[i].marca << endl << "Tipo: " << carro[i].tipo
                            << endl << "Ano: " << carro[i].ano << endl << "Placa: " << carro[i].placa << endl;
                    cout << "--------------------------------------------------------------------------------------\n";
                    cout << "Deseja excluir o carro do Banco de Dados ?\n 1 - sim \n 2 - não\n opção -> ";
                    cin >> op;
                    switch(op){// switch para excuir ou não os veiculos
                        case 1:
                            carro[i].valido = false;
                            cout << "Item excluido com sucesso....\n";
                            break;
                        case 2:
                                break;
                        default:
                            cout << "Opção invalida";
                    }
                    break;
                }else if (encontrado != 1){
                    cout << "\n\nVeiculo não encontrado no  Banco de dados\n";
                }
                cout << "Digite 0 para sair ou outro para voltar ao menu: "; // fim dda operação
                cin >> op;
                system("clear");
                break;
            case 2: // busca por tipo
                system("clear");
                busca = ""; // variavel padrão para buscas
                cout << "Digite o tipo do veiculo ->  ";
                cin >> busca;
                system("clear");
                for (i = 0; carro[i].modelo != "fim"; i++){
                    if (busca == carro[i].tipo && carro[i].valido == true){// verificando se o veiculo existe ou é valido
                        cout << "Modelo: " << carro[i].modelo << endl << "Marca: " << carro[i].marca << endl << "Tipo: " << carro[i].tipo
                            << endl << "Ano: " << carro[i].ano << endl << "Placa: " << carro[i].placa << endl << endl;
                    }
                }
                cout << "Digite 0 para sair ou outro para voltar ao menu: ";
                cin >> op;
                break;
            case 3: // busca por Câbio
                busca = ""; // variavel padrão para buscas
                cout << "Digite o tipo do câmbio do veiculo ->  ";
                cin >> busca;
                system("clear");
                for (i = 0; carro[i].modelo != "fim"; i++){
                    if (busca == carro[i].cambio && carro[i].valido == true){// verificando se o veiculo existe ou é valido
                        cout << "Modelo: " << carro[i].modelo << endl << "Marca: " << carro[i].marca << endl << "câmbio: " << carro[i].cambio
                            << endl << "Ano: " << carro[i].ano << endl << "Placa: " << carro[i].placa << endl << endl;
                    }
                }
                cout << "Digite 0 para sair ou outro para voltar ao menu: ";
                cin >> op;
                break;
            case 4: // busca por Preço
                cout << "Digite o valor minimo do veiculo ->  ";
                cin >> valor;
                cout << "Digite o valor maximo do veiculo ->  ";
                cin >> valor2;
                cout << endl << endl;;
                 for (i = 0; carro[i].modelo != "fim"; i++){
                    if(carro[i].valor >= valor && carro[i].valor <= valor2){
                        cout << "Modelo: " << carro[i].modelo << endl << "Marca: " << carro[i].marca << endl << "tipo: " << carro[i].tipo
                            << endl << "Ano: " << carro[i].ano << endl << "valor: " << carro[i].valor << endl << endl;
                    }
                 }
                cout << "Digite 0 para sair ou outro para voltar ao menu: ";
                cin >> op;
                break;
            case 5: // Inclusão de veiculo no BD
                cout << "Digite os dados Abaixo :\n";
                cout << "Modelo: ";
                cin >> modelo;
                cout << "Marca: ";
                cin >> marca;
                cout << "Tipo: ";
                cin >> tipo;
                cout << "Ano: ";
                cin >> ano;
                cout << "Km rodado: ";
                cin >> km;
                cout << "Potência: ";
                cin >> potencia;
                cout << "Combustivel: ";
                cin >> combustivel;
                cout << "Câmbio: ";
                cin >> cambio;
                cout << "Direção: ";
                cin >> direcao;
                cout << "Cor: ";
                cin >> cor;
                cout << "Porta: ";
                cin >> portas;
                cout << "Placa: ";
                cin >> placa;
                cout << "Valor: ";
                cin >> preco;
                encontrado = 0;
                for (int i = 0; carro[i].modelo != "\0"; i++){ // verificando overflow no vetor
                    if(i > TAM){
                        cout << "Tamanho maximo do banco de dados excerdido.\n";
                    }else // adicionando
                        if(carro[i].valido == false){ // caso encontre uma posição invalida
                            carro[i].modelo = modelo;
                            carro[i].marca = marca;
                            carro[i].tipo = tipo;
                            carro[i].ano = ano;
                            carro[i].km = km;
                            carro[i].potencia = potencia;
                            carro[i].combustivel = combustivel;
                            carro[i].cambio = cambio;
                            carro[i].direcao = direcao;
                            carro[i].cor = cor;
                            carro[i].portas = portas;
                            carro[i].placa = placa;
                            carro[i].valor = preco;
                            carro[i].valido = true;
                            encontrado = 1;
                            break;

                        }if (encontrado == 0 && carro[i].modelo == "fim"){caso não encontre uma posição invalida
                            carro[i].modelo = modelo;
                            carro[i].marca = marca;
                            carro[i].tipo = tipo;
                            carro[i].ano = ano;
                            carro[i].km = km;
                            carro[i].potencia = potencia;
                            carro[i].combustivel = combustivel;
                            carro[i].cambio = cambio;
                            carro[i].direcao = direcao;
                            carro[i].cor = cor;
                            carro[i].portas = portas;
                            carro[i].placa = placa;
                            carro[i].valor = preco;
                            carro[i+1].modelo = "fim";
                            carro[i].valido = true;
                            break;
                        }   
                }
                cout << "Digite 0 para sair ou outro para voltar ao menu: ";
                cin >> op;
                break;
            
            case 6: // relatorio
                system("clear");
                cout << "Gerando relatorio .....\n\n";
                for (int i = 0; carro[i].modelo != "\0"; i++){ // percorrendo o vetor
                    if(carro[i].valido == true){ // porcentagem tipo
                        
                        // porcentagem tipo e somatorios do mesmo tipo
                        if(carro[i].tipo == "Hatch"){
                            hatch += 1;
                        }else if(carro[i].tipo == "SUV"){
                            suv += 1;
                        } else if(carro[i].tipo == "Pick-up"){
                            pickup += 1;
                        } else if (carro[i].tipo == "Sedan"){
                            seda += 1;
                        } else if (carro[i].tipo == "Van"){
                            van += 1;
                        } else if (carro[i].tipo == "Passeio"){
                            passeio += 1;
                        }


                        if(carro[i].combustivel == "Flex"){// porcentagem combustivel e somatorios 
                            flex += 1;
                        }else if(carro[i].combustivel == "Diesel"){
                            diesel += 1;
                        }else if(carro[i].combustivel == "Gasolina"){
                            gasolina += 1;
                        }


                        if (carro[i].potencia == 1.0 && carro[i].valor < minvalue){// veiculo mais barato 
                            minvalue = carro[i].valor;
                            carromin = i; // atribuindo indice do carro mais barato
                        }



                        if(carro[i].direcao == "Hidraulica" && carro[i].cambio == "Automatico" && carro[i].valor > maxvalue){ // veiculo mais caro Hidraulico e Automatico
                            maxvalue = carro[i].valor;
                            carromax = i; // atribuindo indice
                        }
                        
                        
                        if(carro[i].ano < 2019){ // media de carros 5 anos
                            qntd += 1; // somatorio
                            media[i] = carro[i].km; // vetor criado para armazenar valores de KM de cada carro
                            conjunto =  media[i] + conjunto; // somatorio de quilometregem 
                        }
                       
                    }
                    totalveiculos += 1; // total de veiculos no banco de dado (validos)
                }
                
                //porcentagem, calculo e exebiçao tipo
                hatch = (hatch * 100)/totalveiculos;
                suv = (suv * 100)/totalveiculos;
                pickup = (pickup * 100)/totalveiculos;
                seda = (seda * 100)/totalveiculos;
                van = (van * 100)/totalveiculos;
                passeio = (passeio * 100)/totalveiculos;
                printf ("Hatch = %.2f%\n", hatch);
                printf ("SUV = %.2f%\n", suv);
                printf ("Pick-Up = %.2f%\n", pickup);
                printf ("Sedan = %.4f%\n", seda);
                printf ("Passeio = %.4f%\n", passeio);
                printf ("Van = %.4f%\n\n", van);

                //porcentagem, calculo e exebiçao combustivel
                gasolina = (gasolina * 100)/totalveiculos;
                flex = (flex * 100)/totalveiculos;
                diesel = (diesel * 100)/totalveiculos;
                printf ("Gasolina = %.2f%\n", gasolina);
                printf ("Flex = %.4f%\n", flex);
                printf ("Diesel = %.4f%\n\n", diesel);

                //calculando financiamento em 60x com taxa anual de 11,5%
                jurosmes = 11.5 / 100 / 12;
                financiamento = carro[carromin].valor * (pow(1 + jurosmes, 60.0) * jurosmes) / (pow(1 + jurosmes, 60.0) - 1);

                //calculando Seguro usando com 2% do valor do veiculo
                seguro = carro[carromax].valor * (2/100) ;
                
                // calculo média carros 5 anos +
                med = conjunto / qntd;
                
                //outputs
                cout << "Carro mais barato 1.0 é o: " << carro[carromin].marca << " " << carro[carromin].modelo << " \nplaca: " << carro[carromin].placa << "\ncustando R$ " << carro[carromin].valor << endl << "Parcelas de R$ " << financiamento << " ao mês em 60x\tjuros = 11,5%a.a" << endl;
                cout << "\n\nCarro mais caro Hidraulico/Altomático é o: " << carro[carromax].marca << " " << carro[carromax].modelo << " \nplaca: " << carro[carromax].placa << "\ncustando R$ " << carro[carromax].valor << endl << "seguro de R$ " << seguro << " ao Ano  \ttaxa = 2%a.a" << endl;
                cout << "\n\nMedia de Km de veiculos com 5 anos ou mais:  \ntotal veiculos: " << qntd << "\nmedia: " << med  << " km"<< endl;


                cout << "\n\nDigite 0 para sair ou outro para voltar ao menu: ";
                cin >> op;
                break;
            default: // se op diferente do menu
                cout << "Opção invalida !!\n";
                break;
        }

    }while(op!=0);
    ofstream BD_save("BD_veiculos.txt"); // abrindo arquivo para salvamento
    if(!BD_save.is_open()){ // verificando arquivo
        cout << "erro ao salvar as alterações...." << endl;
    }else
        for (int i = 0; carro[i].modelo != "\0"; i++) // salvando alterações
            if (carro[i].valido == true){
                BD_save << carro[i].modelo << " " << carro[i].marca << " " << carro[i].tipo << " " << carro[i].ano << " " << carro[i].km << " " << carro[i].potencia << " " << carro[i].combustivel << " " << carro[i].cambio << " " << carro[i].direcao << " " << carro[i].cor << " " << carro[i].portas << " " << carro[i].placa << " " << carro[i].valor << endl;;
            }
        cout << "alterações salvas com sucesso" << endl;
    cout << "\nencerrando....";

    return 0;
}
