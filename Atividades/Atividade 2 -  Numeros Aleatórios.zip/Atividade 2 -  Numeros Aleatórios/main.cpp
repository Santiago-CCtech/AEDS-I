
/* 
 * File:   main.cpp
 * Author: Eurico Santiago Climaco Rodrigues
 *
 * Created on 28 de março de 2024, 14:59
 */

#include <cstdlib>
#include <stdio.h>
#include <iostream>
#include <time.h>


using namespace std;

/*
 * 
 * Descrição: crie um projeto em C/C++ que gere aleatoriamente 1000 valores de 
 * alturas de pessoas entre 1.5 e 2.3 metros, calcule a média, encontre a maior 
 * altura, encontre a menor altura e encontre a porcentagem de pessoas maiores 
 * que 2,0 metros.]
 * 
 */
int main(int argc, char** argv) { // inicio main  
    //variaveis ----------------
    int alturas_cm, min, max, i;
    float alturas_m, somatorio, media, maior_altura, menor_altura, maiorde2, porcentagem;
    // -------------------------   
    //inicializando variaveis
    i = 1; 
    min = 149;
    max = 230;
    somatorio = 0;
    maior_altura = 1.5;
    menor_altura = 2.3;
    maiorde2 = 0.0;
    // ------------------ 
    // inicializando numeros aleatorios e o limitando
    srand(time(NULL));
    alturas_cm = min + rand() % (max - min) + 1;   
    // ----------------------------------------------
    while (i < 1001){ // inicio da repetição
        alturas_m = alturas_cm/100.0; // converção CM para M
        cout << "Altura Nº "  << i << " = " << alturas_m << "m" << endl; // teste de variação numerica
        somatorio = alturas_m + somatorio;//somando alturas
        if (alturas_m > maior_altura){//condição de altura maior
            maior_altura = alturas_m;
        }
        if (alturas_m < menor_altura){
            menor_altura = alturas_m;
        }
        if(alturas_m > 2.0){
            maiorde2++;
        }// fim das condições
        alturas_cm = min + rand() % (max - min) + 1; // gerando novo numero aleatorio      
        i++; // incremento de i { i++ = i + 1 }
    } // fim da repetição
    media = somatorio / 1000.0;//calculo de media
    porcentagem = (maiorde2*100.0)/1000.0;// calculo de porcentagem
    printf ("\nA média de altura entre as 1000 pessoas é de : %.2fm", media);// exibição da média;
    printf ("\nMenor altura = %.2fm\nMaior altura = %.2fm", menor_altura, maior_altura);// menor e maior altura
    printf ("\nAs pessoas com mais de 2.0m equivale a %.1f%%", porcentagem);// porcentagem   
    return 0;
}// fim main

